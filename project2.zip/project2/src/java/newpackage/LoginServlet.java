package newpackage;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;

import newpackage.LoginBean;
import newpackage.LoginDao;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    //private static final long serialVersionUID = 1 L;
    private LoginDao Ld;

    public void init() {
        Ld = new LoginDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        LoginBean Lb = new LoginBean();
        Lb.setUsername(username);
        Lb.setPassword(password);

        try {
            if (Ld.validate(Lb)) {
                //HttpSession session = request.getSession();
                // session.setAttribute("username",username);
                response.sendRedirect("loginsucess.jsp");
            } else {
                HttpSession session = request.getSession();
                //session.setAttribute("user", username);
                System.out.println(username);
                //response.sendRedirect("login.jsp");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}